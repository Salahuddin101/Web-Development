var express = require('express');
var router = express.Router();
var Tyres = require("../models/Model")

router.get('/', async function(req, res, next) {
  let Product1= await Tyres.find();
  res.render("Tyres/ShowTyres",{Product1});

});
router.get('/addTyres', async function(req, res, next) {
  
  res.render("Tyres/addTyres");

});
router.post('/addTyres', async function(req, res, next) {
  let product = new Tyres(req.body)
  await product.save()
  res.redirect("/Tyres")
  

});
router.get('/delete/:id', async function(req, res, next) {
  console.log(req.params.id)
  await Tyres.findByIdAndDelete(req.params.id);
  res.redirect("/Tyres")  
    
  
  });
  
module.exports = router;


