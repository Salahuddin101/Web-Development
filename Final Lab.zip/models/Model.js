var mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
    name:String,
    company:String,
    dimensions: String,
   
  });
  
  // Create the model using the schema
  const User = mongoose.model('final', userSchema);
  
  // Export the model
  module.exports = User;